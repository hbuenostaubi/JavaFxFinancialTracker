package api;


import java.io.BufferedReader;


public class Main{
    public static void main(String[] args){
        finAPI obj1=new finAPI("monthly", "FB", System.getenv("API-KEY"));


        try{
            BufferedReader buff=obj1.getConnection();
            obj1.setTxt(buff);

            String txt= obj1.getText();
            System.out.println("json:");
            System.out.println(txt);

            System.out.println("The File Below");
            String fileData = obj1.jsonDates(txt);
            String file="datesData.txt";
            WriterString dir = new WriterString(file,fileData);
            dir.printPath();

        }catch (Exception e){
            System.out.println(e.toString());
        }



    }
}