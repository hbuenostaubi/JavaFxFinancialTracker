package api;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.ws.rs.HttpMethod;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.lang.*;
import org.json.simple.parser.ParseException;


public class finAPI{
    private String urlString;
    private String key;
    private String txt;

    public finAPI(String time, String symbol, String key){
        this.key=key;
        this.urlString="https://www.alphavantage.co/query?"+
                getSeries(time)+"&symbol="+symbol+
                "&apikey="+key;
    }
    public void setTxt(BufferedReader buff) throws Exception{
        String line;
        StringBuilder whole= new StringBuilder();
        while(((line = buff.readLine()) != null)){
            whole.append(line.strip());
        }
        this.txt=whole.toString();
    }

    private String getSeries(String time){
        if(time.equals("weekly"))
            return "function=TIME_SERIES_WEEKLY";
        else
            return "function=TIME_SERIES_MONTHLY";
    }

    public BufferedReader getConnection() throws Exception{
        final int conTimeout = 1000;
        HttpURLConnection connection=null;

        final URL url=new URL(this.urlString);
        connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(conTimeout);
        connection.setRequestMethod(HttpMethod.GET);
        //connection.setRequestProperty("api-key", this.key); //formatted in url
        //connection.setRequestProperty("format","json")  //Default

        if(connection.getResponseCode()==200){
            System.out.println("Connected");
            final InputStream inputStream =connection.getInputStream();  //data inputstream? Trana doesn't know type
            final BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(inputStream));
            return bufferedReader;
        }else{
            System.out.println("Not Connected");
            return null;}
    }

    public String getText(){
        return this.txt;
    }
    public void resetText(String file){
        this.txt=file;
    }

    public String jsonDates(String txt) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject response = (JSONObject) parser.parse(txt);
        JSONObject mntly= (JSONObject) response.get("Monthly Time Series");
        String filename="Dates \n";
        for( Object key: mntly.keySet()){
            String keyString=(String)key;
            filename+=keyString +"\n";   ///added a newline
        }
        return filename;
    }


}