package api;

import java.lang.Double;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.ws.rs.HttpMethod;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.lang.*;
import java.util.*;

import org.json.simple.parser.ParseException;
import stockPkg.DateClass;
import stockPkg.StockClass;


public class FinAPI {
    private String urlString;
    private final String KEY = System.getenv("API-KEY");
    private String txt;

    public FinAPI(String time, String symbol){

        this.urlString="https://www.alphavantage.co/query?"+
                getSeries(time)+"&symbol="+symbol+
                "&apikey="+KEY;
    }
    public void setTxt(BufferedReader buff) throws Exception{
        String line;
        StringBuilder whole= new StringBuilder();
        while(((line = buff.readLine()) != null)){
            whole.append(line.strip());
        }
        this.txt=whole.toString();
    }

    private String getSeries(String time){
        if(time.equals("weekly"))
            return "function=TIME_SERIES_WEEKLY";
        else
            return "function=TIME_SERIES_MONTHLY";
    }

    public BufferedReader getConnection() throws Exception{
        final int conTimeout = 1000;
        HttpURLConnection connection=null;

        final URL url=new URL(this.urlString);
        connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(conTimeout);
        connection.setRequestMethod(HttpMethod.GET);

        if(connection.getResponseCode()==200){
            System.out.println("Connected");
            final InputStream inputStream =connection.getInputStream();
            final BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(inputStream));
            return bufferedReader;
        }else{
            System.out.println("Not Connected");
            return null;}
    }

    public String getText(){
        return this.txt;
    }
    public void resetText(String file){
        this.txt=file;
    }


    public Map stockParser(String txt) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject response = (JSONObject) parser.parse(txt);
        JSONObject mntly= (JSONObject) response.get("Monthly Time Series");

        Map<StockClass, List<DateClass>> hMap = new HashMap<>();
        IterMap(mntly, hMap);

        return hMap;
    }

    public void IterMap(JSONObject mntly, Map<StockClass, List<DateClass>> hMap) {
        for(Object key: mntly.keySet()){
            String keyString=(String)key;
            JSONObject dateString= (JSONObject) mntly.get(keyString);
            String date = keyString;
            double open = Double.parseDouble((String) dateString.get("1. open"));
            double high = Double.parseDouble((String) dateString.get("2. high"));
            double low = Double.parseDouble((String) dateString.get("3. low"));
            double close = Double.parseDouble((String) dateString.get("4. close"));
            int volume = Integer.parseInt((String)dateString.get("5. volume"));

            DateClass objTemp =new DateClass(date,open, high, low, close, volume);

            for(StockClass closeCategory: StockClass.values()){
                if(objTemp.getClose()>=closeCategory.getMin() && objTemp.getClose()<=closeCategory.getMax()){
                    addToMap(closeCategory, objTemp, hMap);
                }
            }
        }
    }

    public void addToMap(StockClass key, DateClass obj1, Map<StockClass, List<DateClass>> map){
        if(!map.containsKey(key)){
            map.put(key, new ArrayList<>(Arrays.asList(obj1)));  ///key
        }else{
            map.get(key).add(obj1);
        }
    }

    public Map getAPI() throws Exception {   //getValues
        BufferedReader buff=this.getConnection();

        this.setTxt(buff);

        String txt= this.getText();

        Map<StockClass, List<DateClass>> finData = this.stockParser(txt);

        return finData;

    }


}  ///END