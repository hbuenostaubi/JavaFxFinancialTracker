package stockPkg;


public enum StockClass {
    LOWEST(0, 75.0),
    LOW(76,125),
    MID(126, 175),
    HIGH(176,999);

    private final double min;
    private final double max;

    StockClass(double min, double max){
        this.min=min;
        this.max=max;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }
}
