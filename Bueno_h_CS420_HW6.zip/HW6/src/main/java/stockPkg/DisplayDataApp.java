package stockPkg;


import api.FinAPI;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.util.List;
import java.util.Map;

import static javafx.collections.FXCollections.observableArrayList;

public class DisplayDataApp extends Application {

    public static void main(String[] args) {
            launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {   ///stage var is here!


        final ComboBox<StockClass> categories = new ComboBox<>();
        final ComboBox<DateClass> closeWk = new ComboBox<>();

        closeWk.setPromptText("--Select a value--");
        closeWk.setVisible(false);

        ////I have to add boxes to select API
        FinAPI obj1=new FinAPI("monthly", "FB");
        Map<StockClass, List<DateClass>> hMap = obj1.getAPI();
        ObservableList<StockClass> closeGroup = FXCollections.observableArrayList(hMap.keySet()).sorted();

        categories.getItems().addAll(closeGroup);
        categories.setPromptText("--Select a value--");
        categories.valueProperty().addListener(new ChangeListener<StockClass>() {
            @Override
            public void changed(ObservableValue<? extends StockClass> observable, StockClass oldValue, StockClass newValue) {
                closeWk.getItems().clear();
                closeWk.getItems().addAll(hMap.get(newValue));
                closeWk.setVisible(true);
            }
        });


        BorderPane pane = new BorderPane();
        pane.setTop(categories);
        pane.setCenter(closeWk);
        Scene scene = new Scene(pane, 300, 300);
        stage.setScene(scene);
        stage.setTitle("Financial Tracker");
        stage.show();

    }
}
